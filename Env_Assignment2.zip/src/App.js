//import logo from './logo.svg';
import './App.css';
import RegistrationPage from './components/RegistrationPage';


//import Sidebar from './sidebar/sidebar';
import './App.css';
import HomePage from './HomePage';

//import { Routes as Switch, Route } from 'react-router-dom';
//import { BrowserRouter as Router} from 'react-router-dom';
//import {Chapter1, GettingReady, Variables, Comments} from './pages/chapter1';
//import { Chapter2, Introduction_to_Android, Introduction_to_AndroidStudio, Tools_Required } from './pages/chapter2';


function App() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [username, setUsername] = useState('');
  function handleSignInSubmit(username, password) {
    // Here, you would normally make an API request to your server to validate
    // the user's credentials. For simplicity, we're just hard-coding a check
    // for a specific username and password.
    if (username === 'example' && password === 'password') {
      setLoggedIn(true);
      setUsername(username);
    } else {
      alert('Invalid username or password.');
    }
  }

  function handleLogout() {
    setLoggedIn(false);
    setUsername('');
  }

  return (
    <div>
      {loggedIn ? (
        <div>
          <HomePage username={username} />
          <button onClick={handleLogout}>Log Out</button>
        </div>
      ) : (
        <RegistrationPage onLogin={handleSignInSubmit} />
      )}
    </div>
  );
}

export default App;
