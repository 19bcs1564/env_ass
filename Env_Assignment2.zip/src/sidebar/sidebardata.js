import React from 'react';
//import * as IonIcons from "react-icons/io";
//import * as BiIcons from "react-icons/bi";
import * as RiIcons from "react-icons/ri";
//import VideoPlayer from './videoPlayer';
import * as ImIcons from "react-icons/im";

export const SidebarData = [
    {
                title: 'Chapter 1: Java Basics', 
                path: 'chapter1',
                iconClosed: <RiIcons.RiArrowDownSFill />,
                iconOpened: <RiIcons.RiArrowUpSFill />,
        
        subNav:[
            {
                title: '1. Getting Ready',
                icon: <ImIcons.ImFilePlay />,
                path: '/chapter1/getting-ready',
                
                
            },
            {
                title: '2. Variables', 
                icon: <ImIcons.ImFilePlay />,
                path: '/chapter1/variables',
            },
            {
                title: '3. Comments in Java',
                icon: <ImIcons.ImFilePlay />,
                path: '/chapter1/comments',
            },
            {
                title: '4. Basic knowledge',
                icon: <ImIcons.ImFileText2 />,
                path: '/chapter1/basicknowledge',
            }
        ]  

    },
    {
        title: 'Chapter 2: Introduction to Android', 
                path: 'chapter2',
                iconClosed: <RiIcons.RiArrowDownSFill />,
                iconOpened: <RiIcons.RiArrowUpSFill />,
        
        subNav:[
            {
                title: '1. Introduction to Android', 
                path: '/chapter2/intro',
            },
            {
                title: '2. Introduction to Android Studio', 
                path: '/chapter2/intro_androidStudio',
            },
            //pdf
            {
                title: '3. Tools Required',
                path: '/chapter2/tools',
            }
        ]  

    },
    {
        title: 'Chapter 3: Intents', 
                path: 'chapter3',
                iconClosed: <RiIcons.RiArrowDownSFill />,
                iconOpened: <RiIcons.RiArrowUpSFill />,
        
        subNav:[
            {
                title: '1. Introduction', 
                path: '/chapter3/introduction',
            },
            {
                title: '2. Explicit Intents', 
                path: '/chapter3/explicit_intents',
            },
            //pdf
            {
                title: '3. Implicit Intents',
                path: '/chapter3/implicit_intents',
            },
            //Quiz
            {
                title: '4. Quiz',
                path: '/chapter3/quiz',
            }
        ]  

    },
    {
        title: 'Chapter 4: Fragments', 
                path: 'chapter4',
                iconClosed: <RiIcons.RiArrowDownSFill />,
                iconOpened: <RiIcons.RiArrowUpSFill />,
        
        subNav:[
            {
                title: '1. Introduction to Fragments', 
                path: '/chapter4/introduction_fragments',
            },
            
        ]  

    },
    
    
]

